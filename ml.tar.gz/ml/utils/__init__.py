"""
Utility functions for ML module.
"""

# TODO: Implement utility functions 